A Pen created at CodePen.io. You can find this one at https://codepen.io/validide/pen/aOKLNo.

 A simple table with resizable columns