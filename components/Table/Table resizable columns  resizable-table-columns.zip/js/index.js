$(function() {
  
  $("table").resizableColumns({
    store: window.store
  });
});